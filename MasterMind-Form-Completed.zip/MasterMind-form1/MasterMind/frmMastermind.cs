﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MasterMind
{
    public partial class frmMastermind : Form
    {
        public frmMastermind()
        {
            InitializeComponent();
            txtEnterName.Focus();
            AcceptButton = btnStart;
            lblColorAndPlaceHeader.Visible = false;
            lblColorHeader.Visible = false;
            lblGuess1.Visible = false;
            lblGuess2.Visible = false;
            lblGuess3.Visible = false;
            lblGuess4.Visible = false;
            lblGuess5.Visible = false;
            lblGuess6.Visible = false;
            lblGuess7.Visible = false;
            lblGuess8.Visible = false;
            lblGuess9.Visible = false;
            lblGuess10.Visible = false;
            btnGuess11.Visible = false;
            btnGuess12.Visible = false;
            btnGuess13.Visible = false;
            btnGuess14.Visible = false;
            lblGuess1Color.Visible = false;
            lblGuess1ColorAndPlace.Visible = false;
            btnGuess21.Visible = false;
            btnGuess22.Visible = false;
            btnGuess23.Visible = false;
            btnGuess24.Visible = false;
            lblGuess2Color.Visible = false;
            lblGuess2ColorAndPlace.Visible = false;
            btnGuess31.Visible = false;
            btnGuess32.Visible = false;
            btnGuess33.Visible = false;
            btnGuess34.Visible = false;
            lblGuess3Color.Visible = false;
            lblGuess3ColorAndPlace.Visible = false;
            btnGuess41.Visible = false;
            btnGuess42.Visible = false;
            btnGuess43.Visible = false;
            btnGuess44.Visible = false;
            lblGuess4Color.Visible = false;
            lblGuess4ColorAndPlace.Visible = false;
            btnGuess51.Visible = false;
            btnGuess52.Visible = false;
            btnGuess53.Visible = false;
            btnGuess54.Visible = false;
            lblGuess5Color.Visible = false;
            lblGuess5ColorAndPlace.Visible = false;
            btnGuess61.Visible = false;
            btnGuess62.Visible = false;
            btnGuess63.Visible = false;
            btnGuess64.Visible = false;
            lblGuess6Color.Visible = false;
            lblGuess6ColorAndPlace.Visible = false;
            btnGuess71.Visible = false;
            btnGuess72.Visible = false;
            btnGuess73.Visible = false;
            btnGuess74.Visible = false;
            lblGuess7Color.Visible = false;
            lblGuess7ColorAndPlace.Visible = false;
            btnGuess81.Visible = false;
            btnGuess82.Visible = false;
            btnGuess83.Visible = false;
            btnGuess84.Visible = false;
            lblGuess8Color.Visible = false;
            lblGuess8ColorAndPlace.Visible = false;
            btnGuess91.Visible = false;
            btnGuess92.Visible = false;
            btnGuess93.Visible = false;
            btnGuess94.Visible = false;
            lblGuess9Color.Visible = false;
            lblGuess9ColorAndPlace.Visible = false;
            btnGuess101.Visible = false;
            btnGuess102.Visible = false;
            btnGuess103.Visible = false;
            btnGuess104.Visible = false;
            lblGuess10Color.Visible = false;
            lblGuess10ColorAndPlace.Visible = false;
            lblCurrentGuess.Visible = false;
            btnCurrentGuess1.Visible = false;
            btnCurrentGuess2.Visible = false;
            btnCurrentGuess3.Visible = false;
            btnCurrentGuess4.Visible = false;
            btnSubmitGuess.Visible = false;
            lblSelectDifficulty.Visible = false;
            btnEasy.Visible = false;
            btnMedium.Visible = false;
            btnHard.Visible = false;
            //Height = 125;
            Height = 500;
        }
        int numOfGuesses = 0;
        string currentGuess = "";
        string currentPlayerName;
        GameSolution currentSolution = new GameSolution();

        private void btnCurrentGuess1_Click(object sender, EventArgs e)
        {
            if (btnCurrentGuess1.BackColor == Color.White)
            {
                btnCurrentGuess1.BackColor = Color.Black;
            }
            else if (btnCurrentGuess1.BackColor == Color.Black)
            {
                btnCurrentGuess1.BackColor = Color.Red;
            }
            else if (btnCurrentGuess1.BackColor == Color.Red)
            {
                btnCurrentGuess1.BackColor = Color.Yellow;
            }
            else if (btnCurrentGuess1.BackColor == Color.Yellow)
            {
                btnCurrentGuess1.BackColor = Color.Green;
            }
            else if (btnCurrentGuess1.BackColor == Color.Green)
            {
                btnCurrentGuess1.BackColor = Color.Blue;
            }
            else if (btnCurrentGuess1.BackColor == Color.Blue)
            {
                btnCurrentGuess1.BackColor = Color.White;
            }
        }

        private void btnCurrentGuess2_Click(object sender, EventArgs e)
        {
            if (btnCurrentGuess2.BackColor == Color.White)
            {
                btnCurrentGuess2.BackColor = Color.Black;
            }
            else if (btnCurrentGuess2.BackColor == Color.Black)
            {
                btnCurrentGuess2.BackColor = Color.Red;
            }
            else if (btnCurrentGuess2.BackColor == Color.Red)
            {
                btnCurrentGuess2.BackColor = Color.Yellow;
            }
            else if (btnCurrentGuess2.BackColor == Color.Yellow)
            {
                btnCurrentGuess2.BackColor = Color.Green;
            }
            else if (btnCurrentGuess2.BackColor == Color.Green)
            {
                btnCurrentGuess2.BackColor = Color.Blue;
            }
            else if (btnCurrentGuess2.BackColor == Color.Blue)
            {
                btnCurrentGuess2.BackColor = Color.White;
            }
        }

        private void btnCurrentGuess3_Click(object sender, EventArgs e)
        {
            if (btnCurrentGuess3.BackColor == Color.White)
            {
                btnCurrentGuess3.BackColor = Color.Black;
            }
            else if (btnCurrentGuess3.BackColor == Color.Black)
            {
                btnCurrentGuess3.BackColor = Color.Red;
            }
            else if (btnCurrentGuess3.BackColor == Color.Red)
            {
                btnCurrentGuess3.BackColor = Color.Yellow;
            }
            else if (btnCurrentGuess3.BackColor == Color.Yellow)
            {
                btnCurrentGuess3.BackColor = Color.Green;
            }
            else if (btnCurrentGuess3.BackColor == Color.Green)
            {
                btnCurrentGuess3.BackColor = Color.Blue;
            }
            else if (btnCurrentGuess3.BackColor == Color.Blue)
            {
                btnCurrentGuess3.BackColor = Color.White;
            }
        }

        private void btnCurrentGuess4_Click(object sender, EventArgs e)
        {
            if (btnCurrentGuess4.BackColor == Color.White)
            {
                btnCurrentGuess4.BackColor = Color.Black;
            }
            else if (btnCurrentGuess4.BackColor == Color.Black)
            {
                btnCurrentGuess4.BackColor = Color.Red;
            }
            else if (btnCurrentGuess4.BackColor == Color.Red)
            {
                btnCurrentGuess4.BackColor = Color.Yellow;
            }
            else if (btnCurrentGuess4.BackColor == Color.Yellow)
            {
                btnCurrentGuess4.BackColor = Color.Green;
            }
            else if (btnCurrentGuess4.BackColor == Color.Green)
            {
                btnCurrentGuess4.BackColor = Color.Blue;
            }
            else if (btnCurrentGuess4.BackColor == Color.Blue)
            {
                btnCurrentGuess4.BackColor = Color.White;
            }
        }

        private void btnSubmitGuess_Click(object sender, EventArgs e)
        {
            numOfGuesses++;
            string userGuess1 = Convert.ToString(btnCurrentGuess1.BackColor);
            string userGuess2 = Convert.ToString(btnCurrentGuess2.BackColor);
            string userGuess3 = Convert.ToString(btnCurrentGuess3.BackColor);
            string userGuess4 = Convert.ToString(btnCurrentGuess4.BackColor);
            //MessageBox.Show("userGuess1" + userGuess1);

            if (numOfGuesses == 1)
            {
                lblColorAndPlaceHeader.Visible = true;
                lblColorHeader.Visible = true;
                lblGuess1.Visible = true;
                btnGuess11.Visible = true;
                btnGuess12.Visible = true;
                btnGuess13.Visible = true;
                btnGuess14.Visible = true;
                lblGuess1Color.Visible = true;
                lblGuess1ColorAndPlace.Visible = true;
                //Height = 230;
                btnGuess11.BackColor = btnCurrentGuess1.BackColor;
                btnGuess12.BackColor = btnCurrentGuess2.BackColor;
                btnGuess13.BackColor = btnCurrentGuess3.BackColor;
                btnGuess14.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    /*if (player.bestPlayer(numOfGuesses) = true){ // create method bestPlayer() in player class for each difficulty to find best winner with lowest # of guesses(time factor not initialized yet)
                        MessageBox.Show("You are now on the top scoreboard!");
                        // put "Play again" control disabling here (find it in the else statement of this event handler)
                     }*/
                    resetGame();
                }
                //lblGuess1Color = ;
                //lblGuess1ColorAndPlace = ;
            }
            else if (numOfGuesses == 2)
            {
                lblGuess2.Visible = true;
                btnGuess21.Visible = true;
                btnGuess22.Visible = true;
                btnGuess23.Visible = true;
                btnGuess24.Visible = true;
                lblGuess2Color.Visible = true;
                lblGuess2ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess21.BackColor = btnCurrentGuess1.BackColor;
                btnGuess22.BackColor = btnCurrentGuess2.BackColor;
                btnGuess23.BackColor = btnCurrentGuess3.BackColor;
                btnGuess24.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess2Color = ;
                //lblGuess2ColorAndPlace = ;
            }
            else if (numOfGuesses == 3)
            {
                lblGuess3.Visible = true;
                btnGuess31.Visible = true;
                btnGuess32.Visible = true;
                btnGuess33.Visible = true;
                btnGuess34.Visible = true;
                lblGuess3Color.Visible = true;
                lblGuess3ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess31.BackColor = btnCurrentGuess1.BackColor;
                btnGuess32.BackColor = btnCurrentGuess2.BackColor;
                btnGuess33.BackColor = btnCurrentGuess3.BackColor;
                btnGuess34.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess3Color = ;
                //lblGuess3ColorAndPlace = ;
            }
            else if (numOfGuesses == 4)
            {
                lblGuess4.Visible = true;
                btnGuess41.Visible = true;
                btnGuess42.Visible = true;
                btnGuess43.Visible = true;
                btnGuess44.Visible = true;
                lblGuess4Color.Visible = true;
                lblGuess4ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess41.BackColor = btnCurrentGuess1.BackColor;
                btnGuess42.BackColor = btnCurrentGuess2.BackColor;
                btnGuess43.BackColor = btnCurrentGuess3.BackColor;
                btnGuess44.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess4Color = ;
                //lblGuess4ColorAndPlace = ;
            }
            else if (numOfGuesses == 5)
            {
                lblGuess5.Visible = true;
                btnGuess51.Visible = true;
                btnGuess52.Visible = true;
                btnGuess53.Visible = true;
                btnGuess54.Visible = true;
                lblGuess5Color.Visible = true;
                lblGuess5ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess51.BackColor = btnCurrentGuess1.BackColor;
                btnGuess52.BackColor = btnCurrentGuess2.BackColor;
                btnGuess53.BackColor = btnCurrentGuess3.BackColor;
                btnGuess54.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess5Color = ;
                //lblGuess5ColorAndPlace = ;
            }
            else if (numOfGuesses == 6)
            {
                lblGuess6.Visible = true;
                btnGuess61.Visible = true;
                btnGuess62.Visible = true;
                btnGuess63.Visible = true;
                btnGuess64.Visible = true;
                lblGuess6Color.Visible = true;
                lblGuess6ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess61.BackColor = btnCurrentGuess1.BackColor;
                btnGuess62.BackColor = btnCurrentGuess2.BackColor;
                btnGuess63.BackColor = btnCurrentGuess3.BackColor;
                btnGuess64.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess6Color = ;
                //lblGuess6ColorAndPlace = ;
            }
            else if (numOfGuesses == 7)
            {
                lblGuess7.Visible = true;
                btnGuess71.Visible = true;
                btnGuess72.Visible = true;
                btnGuess73.Visible = true;
                btnGuess74.Visible = true;
                lblGuess7Color.Visible = true;
                lblGuess7ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess71.BackColor = btnCurrentGuess1.BackColor;
                btnGuess72.BackColor = btnCurrentGuess2.BackColor;
                btnGuess73.BackColor = btnCurrentGuess3.BackColor;
                btnGuess74.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess7Color = ;
                //lblGuess7ColorAndPlace = ;
            }
            else if (numOfGuesses == 8)
            {
                lblGuess8.Visible = true;
                btnGuess81.Visible = true;
                btnGuess82.Visible = true;
                btnGuess83.Visible = true;
                btnGuess84.Visible = true;
                lblGuess8Color.Visible = true;
                lblGuess8ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess81.BackColor = btnCurrentGuess1.BackColor;
                btnGuess82.BackColor = btnCurrentGuess2.BackColor;
                btnGuess83.BackColor = btnCurrentGuess3.BackColor;
                btnGuess84.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess8Color = ;
                //lblGuess8ColorAndPlace = ;
            }
            else if (numOfGuesses == 9)
            {
                lblGuess9.Visible = true;
                btnGuess91.Visible = true;
                btnGuess92.Visible = true;
                btnGuess93.Visible = true;
                btnGuess94.Visible = true;
                lblGuess9Color.Visible = true;
                lblGuess9ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess91.BackColor = btnCurrentGuess1.BackColor;
                btnGuess92.BackColor = btnCurrentGuess2.BackColor;
                btnGuess93.BackColor = btnCurrentGuess3.BackColor;
                btnGuess94.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess9Color = ;
                //lblGuess9ColorAndPlace = ;
            }
            else if (numOfGuesses == 10)
            {
                lblGuess10.Visible = true;
                btnGuess101.Visible = true;
                btnGuess102.Visible = true;
                btnGuess103.Visible = true;
                btnGuess104.Visible = true;
                lblGuess10Color.Visible = true;
                lblGuess10ColorAndPlace.Visible = true;
                //Height += 40;
                btnGuess101.BackColor = btnCurrentGuess1.BackColor;
                btnGuess102.BackColor = btnCurrentGuess2.BackColor;
                btnGuess103.BackColor = btnCurrentGuess3.BackColor;
                btnGuess104.BackColor = btnCurrentGuess4.BackColor;
                currentGuess = userGuess1 + userGuess2 + userGuess3 + userGuess4;
                //Checks for winner
                if (currentSolution.isWinner(currentGuess) == true)
                {
                    MessageBox.Show("Congratulations, you are a winner!");
                    resetGame();
                }
                //lblGuess10Color = ;
                //lblGuess10ColorAndPlace = ;
            }
            else // Player loses
            {
                MessageBox.Show("You are a loser. Play again if you dare.");
                resetGame();

            }

        }

        private void frmMastermind_Load(object sender, EventArgs e)
        {
            txtEnterName.Focus();
            AcceptButton = btnStart;
            currentSolution.createRandomSolution(); // Creates a new random solution for current game
            /*lblColorAndPlaceHeader.Visible = false;
            lblColorHeader.Visible = false;
            lblGuess1.Visible = false;
            lblGuess2.Visible = false;
            lblGuess3.Visible = false;
            lblGuess4.Visible = false;
            lblGuess5.Visible = false;
            lblGuess6.Visible = false;
            lblGuess7.Visible = false;
            lblGuess8.Visible = false;
            lblGuess9.Visible = false;
            lblGuess10.Visible = false;
            btnGuess11.Visible = false;
            btnGuess12.Visible = false;
            btnGuess13.Visible = false;
            btnGuess14.Visible = false;
            lblGuess1Color.Visible = false;
            lblGuess1ColorAndPlace.Visible = false;
            btnGuess21.Visible = false;
            btnGuess22.Visible = false;
            btnGuess23.Visible = false;
            btnGuess24.Visible = false;
            lblGuess2Color.Visible = false;
            lblGuess2ColorAndPlace.Visible = false;
            btnGuess31.Visible = false;
            btnGuess32.Visible = false;
            btnGuess33.Visible = false;
            btnGuess34.Visible = false;
            lblGuess3Color.Visible = false;
            lblGuess3ColorAndPlace.Visible = false;
            btnGuess41.Visible = false;
            btnGuess42.Visible = false;
            btnGuess43.Visible = false;
            btnGuess44.Visible = false;
            lblGuess4Color.Visible = false;
            lblGuess4ColorAndPlace.Visible = false;
            btnGuess51.Visible = false;
            btnGuess52.Visible = false;
            btnGuess53.Visible = false;
            btnGuess54.Visible = false;
            lblGuess5Color.Visible = false;
            lblGuess5ColorAndPlace.Visible = false;
            btnGuess61.Visible = false;
            btnGuess62.Visible = false;
            btnGuess63.Visible = false;
            btnGuess64.Visible = false;
            lblGuess6Color.Visible = false;
            lblGuess6ColorAndPlace.Visible = false;
            btnGuess71.Visible = false;
            btnGuess72.Visible = false;
            btnGuess73.Visible = false;
            btnGuess74.Visible = false;
            lblGuess7Color.Visible = false;
            lblGuess7ColorAndPlace.Visible = false;
            btnGuess81.Visible = false;
            btnGuess82.Visible = false;
            btnGuess83.Visible = false;
            btnGuess84.Visible = false;
            lblGuess8Color.Visible = false;
            lblGuess8ColorAndPlace.Visible = false;
            btnGuess91.Visible = false;
            btnGuess92.Visible = false;
            btnGuess93.Visible = false;
            btnGuess94.Visible = false;
            lblGuess9Color.Visible = false;
            lblGuess9ColorAndPlace.Visible = false;
            btnGuess101.Visible = false;
            btnGuess102.Visible = false;
            btnGuess103.Visible = false;
            btnGuess104.Visible = false;
            lblGuess10Color.Visible = false;
            lblGuess10ColorAndPlace.Visible = false;
            //Height = 125;*/
            Height = 525;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            currentPlayerName = txtEnterName.Text;

            if (currentPlayerName == "") // Catches blank player name
            {
                MessageBox.Show("Name cannot be left blank.");
                txtEnterName.Focus();
            }
            else // Display difficulty controls
            {
                txtEnterName.Enabled = false;
                btnStart.Enabled = false;
                lblSelectDifficulty.Visible = true;
                btnEasy.Visible = true;
                btnHard.Visible = true;
                btnMedium.Visible = true;
            }
        }

        private void btnEasy_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Easy mode selected. You have 12 tries to guess the solution.");
            lblCurrentGuess.Visible = true;
            btnCurrentGuess1.Visible = true;
            btnCurrentGuess2.Visible = true;
            btnCurrentGuess3.Visible = true;
            btnCurrentGuess4.Visible = true;
            btnSubmitGuess.Visible = true;
            btnCurrentGuess1.Focus();
            AcceptButton = btnSubmitGuess;
            btnEasy.Enabled = false;
            btnMedium.Enabled = false;
            btnHard.Enabled = false;
        }

        private void btnMedium_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Easy mode selected. You have 10 tries to guess the solution.");
            lblCurrentGuess.Visible = true;
            btnCurrentGuess1.Visible = true;
            btnCurrentGuess2.Visible = true;
            btnCurrentGuess3.Visible = true;
            btnCurrentGuess4.Visible = true;
            btnSubmitGuess.Visible = true;
            AcceptButton = btnSubmitGuess;
            btnCurrentGuess1.Focus();
            btnEasy.Enabled = false;
            btnMedium.Enabled = false;
            btnHard.Enabled = false;
        }

        private void btnHard_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Easy mode selected. You have 8 tries to guess the solution.");
            lblCurrentGuess.Visible = true;
            btnCurrentGuess1.Visible = true;
            btnCurrentGuess2.Visible = true;
            btnCurrentGuess3.Visible = true;
            btnCurrentGuess4.Visible = true;
            btnSubmitGuess.Visible = true;
            btnCurrentGuess1.Focus();
            AcceptButton = btnSubmitGuess;
            btnEasy.Enabled = false;
            btnMedium.Enabled = false;
            btnHard.Enabled = false;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void resetGame()
        {
            numOfGuesses = 0; // Resets guess counter
            // Alters controls so user can play again
            AcceptButton = btnSubmitGuess;
            btnCurrentGuess1.BackColor = Color.White;
            btnCurrentGuess2.BackColor = Color.White;
            btnCurrentGuess3.BackColor = Color.White;
            btnCurrentGuess4.BackColor = Color.White;
            txtEnterName.Enabled = true;
            btnStart.Enabled = true;
            btnEasy.Enabled = true;
            btnMedium.Enabled = true;
            btnHard.Enabled = true;
            AcceptButton = btnStart;
            btnStart.Text = "Play again";
            txtEnterName.Focus();
            lblColorAndPlaceHeader.Visible = false;
            lblColorHeader.Visible = false;
            lblGuess1.Visible = false;
            lblGuess2.Visible = false;
            lblGuess3.Visible = false;
            lblGuess4.Visible = false;
            lblGuess5.Visible = false;
            lblGuess6.Visible = false;
            lblGuess7.Visible = false;
            lblGuess8.Visible = false;
            lblGuess9.Visible = false;
            lblGuess10.Visible = false;
            btnGuess11.Visible = false;
            btnGuess12.Visible = false;
            btnGuess13.Visible = false;
            btnGuess14.Visible = false;
            lblGuess1Color.Visible = false;
            lblGuess1ColorAndPlace.Visible = false;
            btnGuess21.Visible = false;
            btnGuess22.Visible = false;
            btnGuess23.Visible = false;
            btnGuess24.Visible = false;
            lblGuess2Color.Visible = false;
            lblGuess2ColorAndPlace.Visible = false;
            btnGuess31.Visible = false;
            btnGuess32.Visible = false;
            btnGuess33.Visible = false;
            btnGuess34.Visible = false;
            lblGuess3Color.Visible = false;
            lblGuess3ColorAndPlace.Visible = false;
            btnGuess41.Visible = false;
            btnGuess42.Visible = false;
            btnGuess43.Visible = false;
            btnGuess44.Visible = false;
            lblGuess4Color.Visible = false;
            lblGuess4ColorAndPlace.Visible = false;
            btnGuess51.Visible = false;
            btnGuess52.Visible = false;
            btnGuess53.Visible = false;
            btnGuess54.Visible = false;
            lblGuess5Color.Visible = false;
            lblGuess5ColorAndPlace.Visible = false;
            btnGuess61.Visible = false;
            btnGuess62.Visible = false;
            btnGuess63.Visible = false;
            btnGuess64.Visible = false;
            lblGuess6Color.Visible = false;
            lblGuess6ColorAndPlace.Visible = false;
            btnGuess71.Visible = false;
            btnGuess72.Visible = false;
            btnGuess73.Visible = false;
            btnGuess74.Visible = false;
            lblGuess7Color.Visible = false;
            lblGuess7ColorAndPlace.Visible = false;
            btnGuess81.Visible = false;
            btnGuess82.Visible = false;
            btnGuess83.Visible = false;
            btnGuess84.Visible = false;
            lblGuess8Color.Visible = false;
            lblGuess8ColorAndPlace.Visible = false;
            btnGuess91.Visible = false;
            btnGuess92.Visible = false;
            btnGuess93.Visible = false;
            btnGuess94.Visible = false;
            lblGuess9Color.Visible = false;
            lblGuess9ColorAndPlace.Visible = false;
            btnGuess101.Visible = false;
            btnGuess102.Visible = false;
            btnGuess103.Visible = false;
            btnGuess104.Visible = false;
            lblGuess10Color.Visible = false;
            lblGuess10ColorAndPlace.Visible = false;
            lblCurrentGuess.Visible = false;
            btnCurrentGuess1.Visible = false;
            btnCurrentGuess2.Visible = false;
            btnCurrentGuess3.Visible = false;
            btnCurrentGuess4.Visible = false;
            btnSubmitGuess.Visible = false;
            lblSelectDifficulty.Visible = false;
            btnEasy.Visible = false;
            btnMedium.Visible = false;
            btnHard.Visible = false;
        }
    }
}
