﻿namespace MasterMind
{
    partial class frmMastermind
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCurrentGuess = new System.Windows.Forms.Label();
            this.btnCurrentGuess1 = new System.Windows.Forms.Button();
            this.btnCurrentGuess2 = new System.Windows.Forms.Button();
            this.btnCurrentGuess3 = new System.Windows.Forms.Button();
            this.btnCurrentGuess4 = new System.Windows.Forms.Button();
            this.btnSubmitGuess = new System.Windows.Forms.Button();
            this.btnGuess11 = new System.Windows.Forms.Button();
            this.btnGuess14 = new System.Windows.Forms.Button();
            this.btnGuess13 = new System.Windows.Forms.Button();
            this.btnGuess12 = new System.Windows.Forms.Button();
            this.lblColorHeader = new System.Windows.Forms.Label();
            this.lblColorAndPlaceHeader = new System.Windows.Forms.Label();
            this.lblGuess1Color = new System.Windows.Forms.Label();
            this.lblGuess1ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess1 = new System.Windows.Forms.Label();
            this.lblGuess2 = new System.Windows.Forms.Label();
            this.lblGuess2ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess2Color = new System.Windows.Forms.Label();
            this.btnGuess22 = new System.Windows.Forms.Button();
            this.btnGuess23 = new System.Windows.Forms.Button();
            this.btnGuess24 = new System.Windows.Forms.Button();
            this.btnGuess21 = new System.Windows.Forms.Button();
            this.lblGuess3 = new System.Windows.Forms.Label();
            this.lblGuess3ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess3Color = new System.Windows.Forms.Label();
            this.btnGuess32 = new System.Windows.Forms.Button();
            this.btnGuess33 = new System.Windows.Forms.Button();
            this.btnGuess34 = new System.Windows.Forms.Button();
            this.btnGuess31 = new System.Windows.Forms.Button();
            this.lblGuess4 = new System.Windows.Forms.Label();
            this.lblGuess4ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess4Color = new System.Windows.Forms.Label();
            this.btnGuess42 = new System.Windows.Forms.Button();
            this.btnGuess43 = new System.Windows.Forms.Button();
            this.btnGuess44 = new System.Windows.Forms.Button();
            this.btnGuess41 = new System.Windows.Forms.Button();
            this.lblGuess5 = new System.Windows.Forms.Label();
            this.lblGuess5ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess5Color = new System.Windows.Forms.Label();
            this.btnGuess52 = new System.Windows.Forms.Button();
            this.btnGuess53 = new System.Windows.Forms.Button();
            this.btnGuess54 = new System.Windows.Forms.Button();
            this.btnGuess51 = new System.Windows.Forms.Button();
            this.lblGuess6 = new System.Windows.Forms.Label();
            this.lblGuess6ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess6Color = new System.Windows.Forms.Label();
            this.btnGuess62 = new System.Windows.Forms.Button();
            this.btnGuess63 = new System.Windows.Forms.Button();
            this.btnGuess64 = new System.Windows.Forms.Button();
            this.btnGuess61 = new System.Windows.Forms.Button();
            this.lblGuess7 = new System.Windows.Forms.Label();
            this.lblGuess7ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess7Color = new System.Windows.Forms.Label();
            this.btnGuess72 = new System.Windows.Forms.Button();
            this.btnGuess73 = new System.Windows.Forms.Button();
            this.btnGuess74 = new System.Windows.Forms.Button();
            this.btnGuess71 = new System.Windows.Forms.Button();
            this.lblGuess8 = new System.Windows.Forms.Label();
            this.lblGuess8ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess8Color = new System.Windows.Forms.Label();
            this.btnGuess82 = new System.Windows.Forms.Button();
            this.btnGuess83 = new System.Windows.Forms.Button();
            this.btnGuess84 = new System.Windows.Forms.Button();
            this.btnGuess81 = new System.Windows.Forms.Button();
            this.lblGuess9 = new System.Windows.Forms.Label();
            this.lblGuess9ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess9Color = new System.Windows.Forms.Label();
            this.btnGuess92 = new System.Windows.Forms.Button();
            this.btnGuess93 = new System.Windows.Forms.Button();
            this.btnGuess94 = new System.Windows.Forms.Button();
            this.btnGuess91 = new System.Windows.Forms.Button();
            this.lblGuess10 = new System.Windows.Forms.Label();
            this.lblGuess10ColorAndPlace = new System.Windows.Forms.Label();
            this.lblGuess10Color = new System.Windows.Forms.Label();
            this.btnGuess102 = new System.Windows.Forms.Button();
            this.btnGuess103 = new System.Windows.Forms.Button();
            this.btnGuess104 = new System.Windows.Forms.Button();
            this.btnGuess101 = new System.Windows.Forms.Button();
            this.lblMastermindTitle = new System.Windows.Forms.Label();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblEnterName = new System.Windows.Forms.Label();
            this.txtEnterName = new System.Windows.Forms.TextBox();
            this.lblSelectDifficulty = new System.Windows.Forms.Label();
            this.btnEasy = new System.Windows.Forms.Button();
            this.btnMedium = new System.Windows.Forms.Button();
            this.btnHard = new System.Windows.Forms.Button();
            this.lblScoreboard = new System.Windows.Forms.Label();
            this.txtEasyWinner = new System.Windows.Forms.TextBox();
            this.txtMediumWinner = new System.Windows.Forms.TextBox();
            this.txtHardWinner = new System.Windows.Forms.TextBox();
            this.lblEasyWinner = new System.Windows.Forms.Label();
            this.lblMediumWinner = new System.Windows.Forms.Label();
            this.lblHardWinner = new System.Windows.Forms.Label();
            this.lblModeDisplayWinner = new System.Windows.Forms.Label();
            this.lblNameDisplayWinner = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCurrentGuess
            // 
            this.lblCurrentGuess.AutoSize = true;
            this.lblCurrentGuess.Location = new System.Drawing.Point(492, 50);
            this.lblCurrentGuess.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCurrentGuess.Name = "lblCurrentGuess";
            this.lblCurrentGuess.Size = new System.Drawing.Size(139, 25);
            this.lblCurrentGuess.TabIndex = 0;
            this.lblCurrentGuess.Text = "Current Guess";
            // 
            // btnCurrentGuess1
            // 
            this.btnCurrentGuess1.BackColor = System.Drawing.Color.White;
            this.btnCurrentGuess1.Location = new System.Drawing.Point(653, 18);
            this.btnCurrentGuess1.Margin = new System.Windows.Forms.Padding(4);
            this.btnCurrentGuess1.Name = "btnCurrentGuess1";
            this.btnCurrentGuess1.Size = new System.Drawing.Size(92, 90);
            this.btnCurrentGuess1.TabIndex = 1;
            this.btnCurrentGuess1.UseVisualStyleBackColor = false;
            this.btnCurrentGuess1.Click += new System.EventHandler(this.btnCurrentGuess1_Click);
            // 
            // btnCurrentGuess2
            // 
            this.btnCurrentGuess2.BackColor = System.Drawing.Color.White;
            this.btnCurrentGuess2.Location = new System.Drawing.Point(767, 18);
            this.btnCurrentGuess2.Margin = new System.Windows.Forms.Padding(4);
            this.btnCurrentGuess2.Name = "btnCurrentGuess2";
            this.btnCurrentGuess2.Size = new System.Drawing.Size(92, 90);
            this.btnCurrentGuess2.TabIndex = 2;
            this.btnCurrentGuess2.UseVisualStyleBackColor = false;
            this.btnCurrentGuess2.Click += new System.EventHandler(this.btnCurrentGuess2_Click);
            // 
            // btnCurrentGuess3
            // 
            this.btnCurrentGuess3.BackColor = System.Drawing.Color.White;
            this.btnCurrentGuess3.Location = new System.Drawing.Point(880, 18);
            this.btnCurrentGuess3.Margin = new System.Windows.Forms.Padding(4);
            this.btnCurrentGuess3.Name = "btnCurrentGuess3";
            this.btnCurrentGuess3.Size = new System.Drawing.Size(92, 90);
            this.btnCurrentGuess3.TabIndex = 3;
            this.btnCurrentGuess3.UseVisualStyleBackColor = false;
            this.btnCurrentGuess3.Click += new System.EventHandler(this.btnCurrentGuess3_Click);
            // 
            // btnCurrentGuess4
            // 
            this.btnCurrentGuess4.BackColor = System.Drawing.Color.White;
            this.btnCurrentGuess4.Location = new System.Drawing.Point(995, 18);
            this.btnCurrentGuess4.Margin = new System.Windows.Forms.Padding(4);
            this.btnCurrentGuess4.Name = "btnCurrentGuess4";
            this.btnCurrentGuess4.Size = new System.Drawing.Size(92, 90);
            this.btnCurrentGuess4.TabIndex = 4;
            this.btnCurrentGuess4.UseVisualStyleBackColor = false;
            this.btnCurrentGuess4.Click += new System.EventHandler(this.btnCurrentGuess4_Click);
            // 
            // btnSubmitGuess
            // 
            this.btnSubmitGuess.Location = new System.Drawing.Point(1118, 39);
            this.btnSubmitGuess.Margin = new System.Windows.Forms.Padding(4);
            this.btnSubmitGuess.Name = "btnSubmitGuess";
            this.btnSubmitGuess.Size = new System.Drawing.Size(144, 42);
            this.btnSubmitGuess.TabIndex = 5;
            this.btnSubmitGuess.Text = "Submit Guess";
            this.btnSubmitGuess.UseVisualStyleBackColor = true;
            this.btnSubmitGuess.Click += new System.EventHandler(this.btnSubmitGuess_Click);
            // 
            // btnGuess11
            // 
            this.btnGuess11.BackColor = System.Drawing.Color.White;
            this.btnGuess11.Location = new System.Drawing.Point(693, 191);
            this.btnGuess11.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess11.Name = "btnGuess11";
            this.btnGuess11.Size = new System.Drawing.Size(55, 54);
            this.btnGuess11.TabIndex = 6;
            this.btnGuess11.UseVisualStyleBackColor = false;
            // 
            // btnGuess14
            // 
            this.btnGuess14.BackColor = System.Drawing.Color.White;
            this.btnGuess14.Location = new System.Drawing.Point(880, 191);
            this.btnGuess14.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess14.Name = "btnGuess14";
            this.btnGuess14.Size = new System.Drawing.Size(55, 54);
            this.btnGuess14.TabIndex = 7;
            this.btnGuess14.UseVisualStyleBackColor = false;
            // 
            // btnGuess13
            // 
            this.btnGuess13.BackColor = System.Drawing.Color.White;
            this.btnGuess13.Location = new System.Drawing.Point(818, 191);
            this.btnGuess13.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess13.Name = "btnGuess13";
            this.btnGuess13.Size = new System.Drawing.Size(55, 54);
            this.btnGuess13.TabIndex = 8;
            this.btnGuess13.UseVisualStyleBackColor = false;
            // 
            // btnGuess12
            // 
            this.btnGuess12.BackColor = System.Drawing.Color.White;
            this.btnGuess12.Location = new System.Drawing.Point(755, 191);
            this.btnGuess12.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess12.Name = "btnGuess12";
            this.btnGuess12.Size = new System.Drawing.Size(55, 54);
            this.btnGuess12.TabIndex = 9;
            this.btnGuess12.UseVisualStyleBackColor = false;
            // 
            // lblColorHeader
            // 
            this.lblColorHeader.Location = new System.Drawing.Point(935, 124);
            this.lblColorHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblColorHeader.Name = "lblColorHeader";
            this.lblColorHeader.Size = new System.Drawing.Size(109, 53);
            this.lblColorHeader.TabIndex = 10;
            this.lblColorHeader.Text = "Number of Right Color";
            this.lblColorHeader.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblColorAndPlaceHeader
            // 
            this.lblColorAndPlaceHeader.Location = new System.Drawing.Point(1051, 124);
            this.lblColorAndPlaceHeader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblColorAndPlaceHeader.Name = "lblColorAndPlaceHeader";
            this.lblColorAndPlaceHeader.Size = new System.Drawing.Size(164, 53);
            this.lblColorAndPlaceHeader.TabIndex = 11;
            this.lblColorAndPlaceHeader.Text = "Number of Right Color and Place";
            this.lblColorAndPlaceHeader.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblGuess1Color
            // 
            this.lblGuess1Color.AutoSize = true;
            this.lblGuess1Color.Location = new System.Drawing.Point(973, 205);
            this.lblGuess1Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess1Color.Name = "lblGuess1Color";
            this.lblGuess1Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess1Color.TabIndex = 12;
            this.lblGuess1Color.Text = "0";
            // 
            // lblGuess1ColorAndPlace
            // 
            this.lblGuess1ColorAndPlace.AutoSize = true;
            this.lblGuess1ColorAndPlace.Location = new System.Drawing.Point(1105, 205);
            this.lblGuess1ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess1ColorAndPlace.Name = "lblGuess1ColorAndPlace";
            this.lblGuess1ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess1ColorAndPlace.TabIndex = 13;
            this.lblGuess1ColorAndPlace.Text = "0";
            // 
            // lblGuess1
            // 
            this.lblGuess1.AutoSize = true;
            this.lblGuess1.Location = new System.Drawing.Point(590, 205);
            this.lblGuess1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess1.Name = "lblGuess1";
            this.lblGuess1.Size = new System.Drawing.Size(85, 25);
            this.lblGuess1.TabIndex = 14;
            this.lblGuess1.Text = "Guess 1";
            // 
            // lblGuess2
            // 
            this.lblGuess2.AutoSize = true;
            this.lblGuess2.Location = new System.Drawing.Point(590, 267);
            this.lblGuess2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess2.Name = "lblGuess2";
            this.lblGuess2.Size = new System.Drawing.Size(85, 25);
            this.lblGuess2.TabIndex = 21;
            this.lblGuess2.Text = "Guess 2";
            // 
            // lblGuess2ColorAndPlace
            // 
            this.lblGuess2ColorAndPlace.AutoSize = true;
            this.lblGuess2ColorAndPlace.Location = new System.Drawing.Point(1105, 267);
            this.lblGuess2ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess2ColorAndPlace.Name = "lblGuess2ColorAndPlace";
            this.lblGuess2ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess2ColorAndPlace.TabIndex = 20;
            this.lblGuess2ColorAndPlace.Text = "0";
            // 
            // lblGuess2Color
            // 
            this.lblGuess2Color.AutoSize = true;
            this.lblGuess2Color.Location = new System.Drawing.Point(973, 267);
            this.lblGuess2Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess2Color.Name = "lblGuess2Color";
            this.lblGuess2Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess2Color.TabIndex = 19;
            this.lblGuess2Color.Text = "0";
            // 
            // btnGuess22
            // 
            this.btnGuess22.BackColor = System.Drawing.Color.White;
            this.btnGuess22.Location = new System.Drawing.Point(755, 252);
            this.btnGuess22.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess22.Name = "btnGuess22";
            this.btnGuess22.Size = new System.Drawing.Size(55, 54);
            this.btnGuess22.TabIndex = 18;
            this.btnGuess22.UseVisualStyleBackColor = false;
            // 
            // btnGuess23
            // 
            this.btnGuess23.BackColor = System.Drawing.Color.White;
            this.btnGuess23.Location = new System.Drawing.Point(818, 252);
            this.btnGuess23.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess23.Name = "btnGuess23";
            this.btnGuess23.Size = new System.Drawing.Size(55, 54);
            this.btnGuess23.TabIndex = 17;
            this.btnGuess23.UseVisualStyleBackColor = false;
            // 
            // btnGuess24
            // 
            this.btnGuess24.BackColor = System.Drawing.Color.White;
            this.btnGuess24.Location = new System.Drawing.Point(880, 252);
            this.btnGuess24.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess24.Name = "btnGuess24";
            this.btnGuess24.Size = new System.Drawing.Size(55, 54);
            this.btnGuess24.TabIndex = 16;
            this.btnGuess24.UseVisualStyleBackColor = false;
            // 
            // btnGuess21
            // 
            this.btnGuess21.BackColor = System.Drawing.Color.White;
            this.btnGuess21.Location = new System.Drawing.Point(693, 252);
            this.btnGuess21.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess21.Name = "btnGuess21";
            this.btnGuess21.Size = new System.Drawing.Size(55, 54);
            this.btnGuess21.TabIndex = 15;
            this.btnGuess21.UseVisualStyleBackColor = false;
            // 
            // lblGuess3
            // 
            this.lblGuess3.AutoSize = true;
            this.lblGuess3.Location = new System.Drawing.Point(590, 328);
            this.lblGuess3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess3.Name = "lblGuess3";
            this.lblGuess3.Size = new System.Drawing.Size(85, 25);
            this.lblGuess3.TabIndex = 28;
            this.lblGuess3.Text = "Guess 3";
            // 
            // lblGuess3ColorAndPlace
            // 
            this.lblGuess3ColorAndPlace.AutoSize = true;
            this.lblGuess3ColorAndPlace.Location = new System.Drawing.Point(1105, 328);
            this.lblGuess3ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess3ColorAndPlace.Name = "lblGuess3ColorAndPlace";
            this.lblGuess3ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess3ColorAndPlace.TabIndex = 27;
            this.lblGuess3ColorAndPlace.Text = "0";
            // 
            // lblGuess3Color
            // 
            this.lblGuess3Color.AutoSize = true;
            this.lblGuess3Color.Location = new System.Drawing.Point(973, 328);
            this.lblGuess3Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess3Color.Name = "lblGuess3Color";
            this.lblGuess3Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess3Color.TabIndex = 26;
            this.lblGuess3Color.Text = "0";
            // 
            // btnGuess32
            // 
            this.btnGuess32.BackColor = System.Drawing.Color.White;
            this.btnGuess32.Location = new System.Drawing.Point(755, 313);
            this.btnGuess32.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess32.Name = "btnGuess32";
            this.btnGuess32.Size = new System.Drawing.Size(55, 54);
            this.btnGuess32.TabIndex = 25;
            this.btnGuess32.UseVisualStyleBackColor = false;
            // 
            // btnGuess33
            // 
            this.btnGuess33.BackColor = System.Drawing.Color.White;
            this.btnGuess33.Location = new System.Drawing.Point(818, 313);
            this.btnGuess33.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess33.Name = "btnGuess33";
            this.btnGuess33.Size = new System.Drawing.Size(55, 54);
            this.btnGuess33.TabIndex = 24;
            this.btnGuess33.UseVisualStyleBackColor = false;
            // 
            // btnGuess34
            // 
            this.btnGuess34.BackColor = System.Drawing.Color.White;
            this.btnGuess34.Location = new System.Drawing.Point(880, 313);
            this.btnGuess34.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess34.Name = "btnGuess34";
            this.btnGuess34.Size = new System.Drawing.Size(55, 54);
            this.btnGuess34.TabIndex = 23;
            this.btnGuess34.UseVisualStyleBackColor = false;
            // 
            // btnGuess31
            // 
            this.btnGuess31.BackColor = System.Drawing.Color.White;
            this.btnGuess31.Location = new System.Drawing.Point(693, 313);
            this.btnGuess31.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess31.Name = "btnGuess31";
            this.btnGuess31.Size = new System.Drawing.Size(55, 54);
            this.btnGuess31.TabIndex = 22;
            this.btnGuess31.UseVisualStyleBackColor = false;
            // 
            // lblGuess4
            // 
            this.lblGuess4.AutoSize = true;
            this.lblGuess4.Location = new System.Drawing.Point(590, 389);
            this.lblGuess4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess4.Name = "lblGuess4";
            this.lblGuess4.Size = new System.Drawing.Size(85, 25);
            this.lblGuess4.TabIndex = 35;
            this.lblGuess4.Text = "Guess 4";
            // 
            // lblGuess4ColorAndPlace
            // 
            this.lblGuess4ColorAndPlace.AutoSize = true;
            this.lblGuess4ColorAndPlace.Location = new System.Drawing.Point(1105, 389);
            this.lblGuess4ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess4ColorAndPlace.Name = "lblGuess4ColorAndPlace";
            this.lblGuess4ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess4ColorAndPlace.TabIndex = 34;
            this.lblGuess4ColorAndPlace.Text = "0";
            // 
            // lblGuess4Color
            // 
            this.lblGuess4Color.AutoSize = true;
            this.lblGuess4Color.Location = new System.Drawing.Point(973, 389);
            this.lblGuess4Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess4Color.Name = "lblGuess4Color";
            this.lblGuess4Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess4Color.TabIndex = 33;
            this.lblGuess4Color.Text = "0";
            // 
            // btnGuess42
            // 
            this.btnGuess42.BackColor = System.Drawing.Color.White;
            this.btnGuess42.Location = new System.Drawing.Point(755, 375);
            this.btnGuess42.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess42.Name = "btnGuess42";
            this.btnGuess42.Size = new System.Drawing.Size(55, 54);
            this.btnGuess42.TabIndex = 32;
            this.btnGuess42.UseVisualStyleBackColor = false;
            // 
            // btnGuess43
            // 
            this.btnGuess43.BackColor = System.Drawing.Color.White;
            this.btnGuess43.Location = new System.Drawing.Point(818, 375);
            this.btnGuess43.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess43.Name = "btnGuess43";
            this.btnGuess43.Size = new System.Drawing.Size(55, 54);
            this.btnGuess43.TabIndex = 31;
            this.btnGuess43.UseVisualStyleBackColor = false;
            // 
            // btnGuess44
            // 
            this.btnGuess44.BackColor = System.Drawing.Color.White;
            this.btnGuess44.Location = new System.Drawing.Point(880, 375);
            this.btnGuess44.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess44.Name = "btnGuess44";
            this.btnGuess44.Size = new System.Drawing.Size(55, 54);
            this.btnGuess44.TabIndex = 30;
            this.btnGuess44.UseVisualStyleBackColor = false;
            // 
            // btnGuess41
            // 
            this.btnGuess41.BackColor = System.Drawing.Color.White;
            this.btnGuess41.Location = new System.Drawing.Point(693, 375);
            this.btnGuess41.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess41.Name = "btnGuess41";
            this.btnGuess41.Size = new System.Drawing.Size(55, 54);
            this.btnGuess41.TabIndex = 29;
            this.btnGuess41.UseVisualStyleBackColor = false;
            // 
            // lblGuess5
            // 
            this.lblGuess5.AutoSize = true;
            this.lblGuess5.Location = new System.Drawing.Point(590, 450);
            this.lblGuess5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess5.Name = "lblGuess5";
            this.lblGuess5.Size = new System.Drawing.Size(85, 25);
            this.lblGuess5.TabIndex = 42;
            this.lblGuess5.Text = "Guess 5";
            // 
            // lblGuess5ColorAndPlace
            // 
            this.lblGuess5ColorAndPlace.AutoSize = true;
            this.lblGuess5ColorAndPlace.Location = new System.Drawing.Point(1105, 450);
            this.lblGuess5ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess5ColorAndPlace.Name = "lblGuess5ColorAndPlace";
            this.lblGuess5ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess5ColorAndPlace.TabIndex = 41;
            this.lblGuess5ColorAndPlace.Text = "0";
            // 
            // lblGuess5Color
            // 
            this.lblGuess5Color.AutoSize = true;
            this.lblGuess5Color.Location = new System.Drawing.Point(973, 450);
            this.lblGuess5Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess5Color.Name = "lblGuess5Color";
            this.lblGuess5Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess5Color.TabIndex = 40;
            this.lblGuess5Color.Text = "0";
            // 
            // btnGuess52
            // 
            this.btnGuess52.BackColor = System.Drawing.Color.White;
            this.btnGuess52.Location = new System.Drawing.Point(755, 436);
            this.btnGuess52.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess52.Name = "btnGuess52";
            this.btnGuess52.Size = new System.Drawing.Size(55, 54);
            this.btnGuess52.TabIndex = 39;
            this.btnGuess52.UseVisualStyleBackColor = false;
            // 
            // btnGuess53
            // 
            this.btnGuess53.BackColor = System.Drawing.Color.White;
            this.btnGuess53.Location = new System.Drawing.Point(818, 436);
            this.btnGuess53.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess53.Name = "btnGuess53";
            this.btnGuess53.Size = new System.Drawing.Size(55, 54);
            this.btnGuess53.TabIndex = 38;
            this.btnGuess53.UseVisualStyleBackColor = false;
            // 
            // btnGuess54
            // 
            this.btnGuess54.BackColor = System.Drawing.Color.White;
            this.btnGuess54.Location = new System.Drawing.Point(880, 436);
            this.btnGuess54.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess54.Name = "btnGuess54";
            this.btnGuess54.Size = new System.Drawing.Size(55, 54);
            this.btnGuess54.TabIndex = 37;
            this.btnGuess54.UseVisualStyleBackColor = false;
            // 
            // btnGuess51
            // 
            this.btnGuess51.BackColor = System.Drawing.Color.White;
            this.btnGuess51.Location = new System.Drawing.Point(693, 436);
            this.btnGuess51.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess51.Name = "btnGuess51";
            this.btnGuess51.Size = new System.Drawing.Size(55, 54);
            this.btnGuess51.TabIndex = 36;
            this.btnGuess51.UseVisualStyleBackColor = false;
            // 
            // lblGuess6
            // 
            this.lblGuess6.AutoSize = true;
            this.lblGuess6.Location = new System.Drawing.Point(590, 511);
            this.lblGuess6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess6.Name = "lblGuess6";
            this.lblGuess6.Size = new System.Drawing.Size(85, 25);
            this.lblGuess6.TabIndex = 49;
            this.lblGuess6.Text = "Guess 6";
            // 
            // lblGuess6ColorAndPlace
            // 
            this.lblGuess6ColorAndPlace.AutoSize = true;
            this.lblGuess6ColorAndPlace.Location = new System.Drawing.Point(1105, 511);
            this.lblGuess6ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess6ColorAndPlace.Name = "lblGuess6ColorAndPlace";
            this.lblGuess6ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess6ColorAndPlace.TabIndex = 48;
            this.lblGuess6ColorAndPlace.Text = "0";
            // 
            // lblGuess6Color
            // 
            this.lblGuess6Color.AutoSize = true;
            this.lblGuess6Color.Location = new System.Drawing.Point(973, 511);
            this.lblGuess6Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess6Color.Name = "lblGuess6Color";
            this.lblGuess6Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess6Color.TabIndex = 47;
            this.lblGuess6Color.Text = "0";
            // 
            // btnGuess62
            // 
            this.btnGuess62.BackColor = System.Drawing.Color.White;
            this.btnGuess62.Location = new System.Drawing.Point(755, 497);
            this.btnGuess62.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess62.Name = "btnGuess62";
            this.btnGuess62.Size = new System.Drawing.Size(55, 54);
            this.btnGuess62.TabIndex = 46;
            this.btnGuess62.UseVisualStyleBackColor = false;
            // 
            // btnGuess63
            // 
            this.btnGuess63.BackColor = System.Drawing.Color.White;
            this.btnGuess63.Location = new System.Drawing.Point(818, 497);
            this.btnGuess63.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess63.Name = "btnGuess63";
            this.btnGuess63.Size = new System.Drawing.Size(55, 54);
            this.btnGuess63.TabIndex = 45;
            this.btnGuess63.UseVisualStyleBackColor = false;
            // 
            // btnGuess64
            // 
            this.btnGuess64.BackColor = System.Drawing.Color.White;
            this.btnGuess64.Location = new System.Drawing.Point(880, 497);
            this.btnGuess64.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess64.Name = "btnGuess64";
            this.btnGuess64.Size = new System.Drawing.Size(55, 54);
            this.btnGuess64.TabIndex = 44;
            this.btnGuess64.UseVisualStyleBackColor = false;
            // 
            // btnGuess61
            // 
            this.btnGuess61.BackColor = System.Drawing.Color.White;
            this.btnGuess61.Location = new System.Drawing.Point(693, 497);
            this.btnGuess61.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess61.Name = "btnGuess61";
            this.btnGuess61.Size = new System.Drawing.Size(55, 54);
            this.btnGuess61.TabIndex = 43;
            this.btnGuess61.UseVisualStyleBackColor = false;
            // 
            // lblGuess7
            // 
            this.lblGuess7.AutoSize = true;
            this.lblGuess7.Location = new System.Drawing.Point(590, 573);
            this.lblGuess7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess7.Name = "lblGuess7";
            this.lblGuess7.Size = new System.Drawing.Size(85, 25);
            this.lblGuess7.TabIndex = 56;
            this.lblGuess7.Text = "Guess 7";
            // 
            // lblGuess7ColorAndPlace
            // 
            this.lblGuess7ColorAndPlace.AutoSize = true;
            this.lblGuess7ColorAndPlace.Location = new System.Drawing.Point(1105, 573);
            this.lblGuess7ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess7ColorAndPlace.Name = "lblGuess7ColorAndPlace";
            this.lblGuess7ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess7ColorAndPlace.TabIndex = 55;
            this.lblGuess7ColorAndPlace.Text = "0";
            // 
            // lblGuess7Color
            // 
            this.lblGuess7Color.AutoSize = true;
            this.lblGuess7Color.Location = new System.Drawing.Point(973, 573);
            this.lblGuess7Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess7Color.Name = "lblGuess7Color";
            this.lblGuess7Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess7Color.TabIndex = 54;
            this.lblGuess7Color.Text = "0";
            // 
            // btnGuess72
            // 
            this.btnGuess72.BackColor = System.Drawing.Color.White;
            this.btnGuess72.Location = new System.Drawing.Point(755, 558);
            this.btnGuess72.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess72.Name = "btnGuess72";
            this.btnGuess72.Size = new System.Drawing.Size(55, 54);
            this.btnGuess72.TabIndex = 53;
            this.btnGuess72.UseVisualStyleBackColor = false;
            // 
            // btnGuess73
            // 
            this.btnGuess73.BackColor = System.Drawing.Color.White;
            this.btnGuess73.Location = new System.Drawing.Point(818, 558);
            this.btnGuess73.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess73.Name = "btnGuess73";
            this.btnGuess73.Size = new System.Drawing.Size(55, 54);
            this.btnGuess73.TabIndex = 52;
            this.btnGuess73.UseVisualStyleBackColor = false;
            // 
            // btnGuess74
            // 
            this.btnGuess74.BackColor = System.Drawing.Color.White;
            this.btnGuess74.Location = new System.Drawing.Point(880, 558);
            this.btnGuess74.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess74.Name = "btnGuess74";
            this.btnGuess74.Size = new System.Drawing.Size(55, 54);
            this.btnGuess74.TabIndex = 51;
            this.btnGuess74.UseVisualStyleBackColor = false;
            // 
            // btnGuess71
            // 
            this.btnGuess71.BackColor = System.Drawing.Color.White;
            this.btnGuess71.Location = new System.Drawing.Point(693, 558);
            this.btnGuess71.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess71.Name = "btnGuess71";
            this.btnGuess71.Size = new System.Drawing.Size(55, 54);
            this.btnGuess71.TabIndex = 50;
            this.btnGuess71.UseVisualStyleBackColor = false;
            // 
            // lblGuess8
            // 
            this.lblGuess8.AutoSize = true;
            this.lblGuess8.Location = new System.Drawing.Point(590, 634);
            this.lblGuess8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess8.Name = "lblGuess8";
            this.lblGuess8.Size = new System.Drawing.Size(85, 25);
            this.lblGuess8.TabIndex = 63;
            this.lblGuess8.Text = "Guess 8";
            // 
            // lblGuess8ColorAndPlace
            // 
            this.lblGuess8ColorAndPlace.AutoSize = true;
            this.lblGuess8ColorAndPlace.Location = new System.Drawing.Point(1105, 634);
            this.lblGuess8ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess8ColorAndPlace.Name = "lblGuess8ColorAndPlace";
            this.lblGuess8ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess8ColorAndPlace.TabIndex = 62;
            this.lblGuess8ColorAndPlace.Text = "0";
            // 
            // lblGuess8Color
            // 
            this.lblGuess8Color.AutoSize = true;
            this.lblGuess8Color.Location = new System.Drawing.Point(973, 634);
            this.lblGuess8Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess8Color.Name = "lblGuess8Color";
            this.lblGuess8Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess8Color.TabIndex = 61;
            this.lblGuess8Color.Text = "0";
            // 
            // btnGuess82
            // 
            this.btnGuess82.BackColor = System.Drawing.Color.White;
            this.btnGuess82.Location = new System.Drawing.Point(755, 619);
            this.btnGuess82.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess82.Name = "btnGuess82";
            this.btnGuess82.Size = new System.Drawing.Size(55, 54);
            this.btnGuess82.TabIndex = 60;
            this.btnGuess82.UseVisualStyleBackColor = false;
            // 
            // btnGuess83
            // 
            this.btnGuess83.BackColor = System.Drawing.Color.White;
            this.btnGuess83.Location = new System.Drawing.Point(818, 619);
            this.btnGuess83.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess83.Name = "btnGuess83";
            this.btnGuess83.Size = new System.Drawing.Size(55, 54);
            this.btnGuess83.TabIndex = 59;
            this.btnGuess83.UseVisualStyleBackColor = false;
            // 
            // btnGuess84
            // 
            this.btnGuess84.BackColor = System.Drawing.Color.White;
            this.btnGuess84.Location = new System.Drawing.Point(880, 619);
            this.btnGuess84.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess84.Name = "btnGuess84";
            this.btnGuess84.Size = new System.Drawing.Size(55, 54);
            this.btnGuess84.TabIndex = 58;
            this.btnGuess84.UseVisualStyleBackColor = false;
            // 
            // btnGuess81
            // 
            this.btnGuess81.BackColor = System.Drawing.Color.White;
            this.btnGuess81.Location = new System.Drawing.Point(693, 619);
            this.btnGuess81.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess81.Name = "btnGuess81";
            this.btnGuess81.Size = new System.Drawing.Size(55, 54);
            this.btnGuess81.TabIndex = 57;
            this.btnGuess81.UseVisualStyleBackColor = false;
            // 
            // lblGuess9
            // 
            this.lblGuess9.AutoSize = true;
            this.lblGuess9.Location = new System.Drawing.Point(590, 695);
            this.lblGuess9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess9.Name = "lblGuess9";
            this.lblGuess9.Size = new System.Drawing.Size(85, 25);
            this.lblGuess9.TabIndex = 70;
            this.lblGuess9.Text = "Guess 9";
            // 
            // lblGuess9ColorAndPlace
            // 
            this.lblGuess9ColorAndPlace.AutoSize = true;
            this.lblGuess9ColorAndPlace.Location = new System.Drawing.Point(1105, 695);
            this.lblGuess9ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess9ColorAndPlace.Name = "lblGuess9ColorAndPlace";
            this.lblGuess9ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess9ColorAndPlace.TabIndex = 69;
            this.lblGuess9ColorAndPlace.Text = "0";
            // 
            // lblGuess9Color
            // 
            this.lblGuess9Color.AutoSize = true;
            this.lblGuess9Color.Location = new System.Drawing.Point(973, 695);
            this.lblGuess9Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess9Color.Name = "lblGuess9Color";
            this.lblGuess9Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess9Color.TabIndex = 68;
            this.lblGuess9Color.Text = "0";
            // 
            // btnGuess92
            // 
            this.btnGuess92.BackColor = System.Drawing.Color.White;
            this.btnGuess92.Location = new System.Drawing.Point(755, 681);
            this.btnGuess92.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess92.Name = "btnGuess92";
            this.btnGuess92.Size = new System.Drawing.Size(55, 54);
            this.btnGuess92.TabIndex = 67;
            this.btnGuess92.UseVisualStyleBackColor = false;
            // 
            // btnGuess93
            // 
            this.btnGuess93.BackColor = System.Drawing.Color.White;
            this.btnGuess93.Location = new System.Drawing.Point(818, 681);
            this.btnGuess93.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess93.Name = "btnGuess93";
            this.btnGuess93.Size = new System.Drawing.Size(55, 54);
            this.btnGuess93.TabIndex = 66;
            this.btnGuess93.UseVisualStyleBackColor = false;
            // 
            // btnGuess94
            // 
            this.btnGuess94.BackColor = System.Drawing.Color.White;
            this.btnGuess94.Location = new System.Drawing.Point(880, 681);
            this.btnGuess94.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess94.Name = "btnGuess94";
            this.btnGuess94.Size = new System.Drawing.Size(55, 54);
            this.btnGuess94.TabIndex = 65;
            this.btnGuess94.UseVisualStyleBackColor = false;
            // 
            // btnGuess91
            // 
            this.btnGuess91.BackColor = System.Drawing.Color.White;
            this.btnGuess91.Location = new System.Drawing.Point(693, 681);
            this.btnGuess91.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess91.Name = "btnGuess91";
            this.btnGuess91.Size = new System.Drawing.Size(55, 54);
            this.btnGuess91.TabIndex = 64;
            this.btnGuess91.UseVisualStyleBackColor = false;
            // 
            // lblGuess10
            // 
            this.lblGuess10.AutoSize = true;
            this.lblGuess10.Location = new System.Drawing.Point(590, 756);
            this.lblGuess10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess10.Name = "lblGuess10";
            this.lblGuess10.Size = new System.Drawing.Size(96, 25);
            this.lblGuess10.TabIndex = 77;
            this.lblGuess10.Text = "Guess 10";
            // 
            // lblGuess10ColorAndPlace
            // 
            this.lblGuess10ColorAndPlace.AutoSize = true;
            this.lblGuess10ColorAndPlace.Location = new System.Drawing.Point(1105, 756);
            this.lblGuess10ColorAndPlace.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess10ColorAndPlace.Name = "lblGuess10ColorAndPlace";
            this.lblGuess10ColorAndPlace.Size = new System.Drawing.Size(23, 25);
            this.lblGuess10ColorAndPlace.TabIndex = 76;
            this.lblGuess10ColorAndPlace.Text = "0";
            // 
            // lblGuess10Color
            // 
            this.lblGuess10Color.AutoSize = true;
            this.lblGuess10Color.Location = new System.Drawing.Point(973, 756);
            this.lblGuess10Color.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGuess10Color.Name = "lblGuess10Color";
            this.lblGuess10Color.Size = new System.Drawing.Size(23, 25);
            this.lblGuess10Color.TabIndex = 75;
            this.lblGuess10Color.Text = "0";
            // 
            // btnGuess102
            // 
            this.btnGuess102.BackColor = System.Drawing.Color.White;
            this.btnGuess102.Location = new System.Drawing.Point(755, 742);
            this.btnGuess102.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess102.Name = "btnGuess102";
            this.btnGuess102.Size = new System.Drawing.Size(55, 54);
            this.btnGuess102.TabIndex = 74;
            this.btnGuess102.UseVisualStyleBackColor = false;
            // 
            // btnGuess103
            // 
            this.btnGuess103.BackColor = System.Drawing.Color.White;
            this.btnGuess103.Location = new System.Drawing.Point(818, 742);
            this.btnGuess103.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess103.Name = "btnGuess103";
            this.btnGuess103.Size = new System.Drawing.Size(55, 54);
            this.btnGuess103.TabIndex = 73;
            this.btnGuess103.UseVisualStyleBackColor = false;
            // 
            // btnGuess104
            // 
            this.btnGuess104.BackColor = System.Drawing.Color.White;
            this.btnGuess104.Location = new System.Drawing.Point(880, 742);
            this.btnGuess104.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess104.Name = "btnGuess104";
            this.btnGuess104.Size = new System.Drawing.Size(55, 54);
            this.btnGuess104.TabIndex = 72;
            this.btnGuess104.UseVisualStyleBackColor = false;
            // 
            // btnGuess101
            // 
            this.btnGuess101.BackColor = System.Drawing.Color.White;
            this.btnGuess101.Location = new System.Drawing.Point(693, 742);
            this.btnGuess101.Margin = new System.Windows.Forms.Padding(4);
            this.btnGuess101.Name = "btnGuess101";
            this.btnGuess101.Size = new System.Drawing.Size(55, 54);
            this.btnGuess101.TabIndex = 71;
            this.btnGuess101.UseVisualStyleBackColor = false;
            // 
            // lblMastermindTitle
            // 
            this.lblMastermindTitle.AutoSize = true;
            this.lblMastermindTitle.Font = new System.Drawing.Font("Modern No. 20", 21.85714F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMastermindTitle.Location = new System.Drawing.Point(67, 64);
            this.lblMastermindTitle.Name = "lblMastermindTitle";
            this.lblMastermindTitle.Size = new System.Drawing.Size(377, 53);
            this.lblMastermindTitle.TabIndex = 78;
            this.lblMastermindTitle.Text = "MASTERMIND";
            // 
            // btnStart
            // 
            this.btnStart.BackColor = System.Drawing.Color.DeepSkyBlue;
            this.btnStart.Location = new System.Drawing.Point(152, 205);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(230, 48);
            this.btnStart.TabIndex = 79;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = false;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblEnterName
            // 
            this.lblEnterName.AutoSize = true;
            this.lblEnterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEnterName.Location = new System.Drawing.Point(76, 148);
            this.lblEnterName.Name = "lblEnterName";
            this.lblEnterName.Size = new System.Drawing.Size(153, 29);
            this.lblEnterName.TabIndex = 80;
            this.lblEnterName.Text = "Enter Name: ";
            // 
            // txtEnterName
            // 
            this.txtEnterName.Location = new System.Drawing.Point(313, 149);
            this.txtEnterName.Name = "txtEnterName";
            this.txtEnterName.Size = new System.Drawing.Size(125, 29);
            this.txtEnterName.TabIndex = 81;
            // 
            // lblSelectDifficulty
            // 
            this.lblSelectDifficulty.AutoSize = true;
            this.lblSelectDifficulty.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.857143F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSelectDifficulty.Location = new System.Drawing.Point(156, 341);
            this.lblSelectDifficulty.Name = "lblSelectDifficulty";
            this.lblSelectDifficulty.Size = new System.Drawing.Size(204, 29);
            this.lblSelectDifficulty.TabIndex = 82;
            this.lblSelectDifficulty.Text = "Select a difficulty: ";
            // 
            // btnEasy
            // 
            this.btnEasy.BackColor = System.Drawing.Color.LimeGreen;
            this.btnEasy.Location = new System.Drawing.Point(43, 401);
            this.btnEasy.Name = "btnEasy";
            this.btnEasy.Size = new System.Drawing.Size(108, 40);
            this.btnEasy.TabIndex = 83;
            this.btnEasy.Text = "Easy";
            this.btnEasy.UseVisualStyleBackColor = false;
            this.btnEasy.Click += new System.EventHandler(this.btnEasy_Click);
            // 
            // btnMedium
            // 
            this.btnMedium.BackColor = System.Drawing.Color.Orange;
            this.btnMedium.Location = new System.Drawing.Point(198, 401);
            this.btnMedium.Name = "btnMedium";
            this.btnMedium.Size = new System.Drawing.Size(118, 40);
            this.btnMedium.TabIndex = 84;
            this.btnMedium.Text = "Medium";
            this.btnMedium.UseVisualStyleBackColor = false;
            this.btnMedium.Click += new System.EventHandler(this.btnMedium_Click);
            // 
            // btnHard
            // 
            this.btnHard.BackColor = System.Drawing.Color.Red;
            this.btnHard.Location = new System.Drawing.Point(365, 401);
            this.btnHard.Name = "btnHard";
            this.btnHard.Size = new System.Drawing.Size(111, 40);
            this.btnHard.TabIndex = 85;
            this.btnHard.Text = "Hard";
            this.btnHard.UseVisualStyleBackColor = false;
            this.btnHard.Click += new System.EventHandler(this.btnHard_Click);
            // 
            // lblScoreboard
            // 
            this.lblScoreboard.AutoSize = true;
            this.lblScoreboard.Font = new System.Drawing.Font("Modern No. 20", 20.14286F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScoreboard.Location = new System.Drawing.Point(90, 514);
            this.lblScoreboard.Name = "lblScoreboard";
            this.lblScoreboard.Size = new System.Drawing.Size(344, 50);
            this.lblScoreboard.TabIndex = 86;
            this.lblScoreboard.Text = "SCOREBOARD";
            // 
            // txtEasyWinner
            // 
            this.txtEasyWinner.Enabled = false;
            this.txtEasyWinner.Location = new System.Drawing.Point(255, 640);
            this.txtEasyWinner.Name = "txtEasyWinner";
            this.txtEasyWinner.Size = new System.Drawing.Size(154, 29);
            this.txtEasyWinner.TabIndex = 87;
            // 
            // txtMediumWinner
            // 
            this.txtMediumWinner.Enabled = false;
            this.txtMediumWinner.Location = new System.Drawing.Point(255, 704);
            this.txtMediumWinner.Name = "txtMediumWinner";
            this.txtMediumWinner.Size = new System.Drawing.Size(154, 29);
            this.txtMediumWinner.TabIndex = 88;
            // 
            // txtHardWinner
            // 
            this.txtHardWinner.Enabled = false;
            this.txtHardWinner.Location = new System.Drawing.Point(255, 766);
            this.txtHardWinner.Name = "txtHardWinner";
            this.txtHardWinner.Size = new System.Drawing.Size(154, 29);
            this.txtHardWinner.TabIndex = 89;
            // 
            // lblEasyWinner
            // 
            this.lblEasyWinner.AutoSize = true;
            this.lblEasyWinner.Location = new System.Drawing.Point(120, 644);
            this.lblEasyWinner.Name = "lblEasyWinner";
            this.lblEasyWinner.Size = new System.Drawing.Size(67, 25);
            this.lblEasyWinner.TabIndex = 90;
            this.lblEasyWinner.Text = "Easy: ";
            // 
            // lblMediumWinner
            // 
            this.lblMediumWinner.AutoSize = true;
            this.lblMediumWinner.Location = new System.Drawing.Point(94, 708);
            this.lblMediumWinner.Name = "lblMediumWinner";
            this.lblMediumWinner.Size = new System.Drawing.Size(93, 25);
            this.lblMediumWinner.TabIndex = 91;
            this.lblMediumWinner.Text = "Medium: ";
            // 
            // lblHardWinner
            // 
            this.lblHardWinner.AutoSize = true;
            this.lblHardWinner.Location = new System.Drawing.Point(122, 766);
            this.lblHardWinner.Name = "lblHardWinner";
            this.lblHardWinner.Size = new System.Drawing.Size(65, 25);
            this.lblHardWinner.TabIndex = 92;
            this.lblHardWinner.Text = "Hard: ";
            // 
            // lblModeDisplayWinner
            // 
            this.lblModeDisplayWinner.AutoSize = true;
            this.lblModeDisplayWinner.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModeDisplayWinner.Location = new System.Drawing.Point(120, 582);
            this.lblModeDisplayWinner.Name = "lblModeDisplayWinner";
            this.lblModeDisplayWinner.Size = new System.Drawing.Size(98, 30);
            this.lblModeDisplayWinner.TabIndex = 93;
            this.lblModeDisplayWinner.Text = "MODE";
            // 
            // lblNameDisplayWinner
            // 
            this.lblNameDisplayWinner.AutoSize = true;
            this.lblNameDisplayWinner.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameDisplayWinner.Location = new System.Drawing.Point(284, 582);
            this.lblNameDisplayWinner.Name = "lblNameDisplayWinner";
            this.lblNameDisplayWinner.Size = new System.Drawing.Size(98, 30);
            this.lblNameDisplayWinner.TabIndex = 94;
            this.lblNameDisplayWinner.Text = "NAME";
            // 
            // btnExit
            // 
            this.btnExit.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnExit.Location = new System.Drawing.Point(1180, 805);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(105, 51);
            this.btnExit.TabIndex = 95;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMastermind
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnExit;
            this.ClientSize = new System.Drawing.Size(1307, 878);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblNameDisplayWinner);
            this.Controls.Add(this.lblModeDisplayWinner);
            this.Controls.Add(this.lblHardWinner);
            this.Controls.Add(this.lblMediumWinner);
            this.Controls.Add(this.lblEasyWinner);
            this.Controls.Add(this.txtHardWinner);
            this.Controls.Add(this.txtMediumWinner);
            this.Controls.Add(this.txtEasyWinner);
            this.Controls.Add(this.lblScoreboard);
            this.Controls.Add(this.btnHard);
            this.Controls.Add(this.btnMedium);
            this.Controls.Add(this.btnEasy);
            this.Controls.Add(this.lblSelectDifficulty);
            this.Controls.Add(this.txtEnterName);
            this.Controls.Add(this.lblEnterName);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.lblMastermindTitle);
            this.Controls.Add(this.lblGuess10);
            this.Controls.Add(this.lblGuess10ColorAndPlace);
            this.Controls.Add(this.lblGuess10Color);
            this.Controls.Add(this.btnGuess102);
            this.Controls.Add(this.btnGuess103);
            this.Controls.Add(this.btnGuess104);
            this.Controls.Add(this.btnGuess101);
            this.Controls.Add(this.lblGuess9);
            this.Controls.Add(this.lblGuess9ColorAndPlace);
            this.Controls.Add(this.lblGuess9Color);
            this.Controls.Add(this.btnGuess92);
            this.Controls.Add(this.btnGuess93);
            this.Controls.Add(this.btnGuess94);
            this.Controls.Add(this.btnGuess91);
            this.Controls.Add(this.lblGuess8);
            this.Controls.Add(this.lblGuess8ColorAndPlace);
            this.Controls.Add(this.lblGuess8Color);
            this.Controls.Add(this.btnGuess82);
            this.Controls.Add(this.btnGuess83);
            this.Controls.Add(this.btnGuess84);
            this.Controls.Add(this.btnGuess81);
            this.Controls.Add(this.lblGuess7);
            this.Controls.Add(this.lblGuess7ColorAndPlace);
            this.Controls.Add(this.lblGuess7Color);
            this.Controls.Add(this.btnGuess72);
            this.Controls.Add(this.btnGuess73);
            this.Controls.Add(this.btnGuess74);
            this.Controls.Add(this.btnGuess71);
            this.Controls.Add(this.lblGuess6);
            this.Controls.Add(this.lblGuess6ColorAndPlace);
            this.Controls.Add(this.lblGuess6Color);
            this.Controls.Add(this.btnGuess62);
            this.Controls.Add(this.btnGuess63);
            this.Controls.Add(this.btnGuess64);
            this.Controls.Add(this.btnGuess61);
            this.Controls.Add(this.lblGuess5);
            this.Controls.Add(this.lblGuess5ColorAndPlace);
            this.Controls.Add(this.lblGuess5Color);
            this.Controls.Add(this.btnGuess52);
            this.Controls.Add(this.btnGuess53);
            this.Controls.Add(this.btnGuess54);
            this.Controls.Add(this.btnGuess51);
            this.Controls.Add(this.lblGuess4);
            this.Controls.Add(this.lblGuess4ColorAndPlace);
            this.Controls.Add(this.lblGuess4Color);
            this.Controls.Add(this.btnGuess42);
            this.Controls.Add(this.btnGuess43);
            this.Controls.Add(this.btnGuess44);
            this.Controls.Add(this.btnGuess41);
            this.Controls.Add(this.lblGuess3);
            this.Controls.Add(this.lblGuess3ColorAndPlace);
            this.Controls.Add(this.lblGuess3Color);
            this.Controls.Add(this.btnGuess32);
            this.Controls.Add(this.btnGuess33);
            this.Controls.Add(this.btnGuess34);
            this.Controls.Add(this.btnGuess31);
            this.Controls.Add(this.lblGuess2);
            this.Controls.Add(this.lblGuess2ColorAndPlace);
            this.Controls.Add(this.lblGuess2Color);
            this.Controls.Add(this.btnGuess22);
            this.Controls.Add(this.btnGuess23);
            this.Controls.Add(this.btnGuess24);
            this.Controls.Add(this.btnGuess21);
            this.Controls.Add(this.lblGuess1);
            this.Controls.Add(this.lblGuess1ColorAndPlace);
            this.Controls.Add(this.lblGuess1Color);
            this.Controls.Add(this.lblColorAndPlaceHeader);
            this.Controls.Add(this.lblColorHeader);
            this.Controls.Add(this.btnGuess12);
            this.Controls.Add(this.btnGuess13);
            this.Controls.Add(this.btnGuess14);
            this.Controls.Add(this.btnGuess11);
            this.Controls.Add(this.btnSubmitGuess);
            this.Controls.Add(this.btnCurrentGuess4);
            this.Controls.Add(this.btnCurrentGuess3);
            this.Controls.Add(this.btnCurrentGuess2);
            this.Controls.Add(this.btnCurrentGuess1);
            this.Controls.Add(this.lblCurrentGuess);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMastermind";
            this.Text = "Mastermind";
            this.Load += new System.EventHandler(this.frmMastermind_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCurrentGuess;
        private System.Windows.Forms.Button btnCurrentGuess1;
        private System.Windows.Forms.Button btnCurrentGuess2;
        private System.Windows.Forms.Button btnCurrentGuess3;
        private System.Windows.Forms.Button btnCurrentGuess4;
        private System.Windows.Forms.Button btnSubmitGuess;
        private System.Windows.Forms.Button btnGuess11;
        private System.Windows.Forms.Button btnGuess14;
        private System.Windows.Forms.Button btnGuess13;
        private System.Windows.Forms.Button btnGuess12;
        private System.Windows.Forms.Label lblColorHeader;
        private System.Windows.Forms.Label lblColorAndPlaceHeader;
        private System.Windows.Forms.Label lblGuess1Color;
        private System.Windows.Forms.Label lblGuess1ColorAndPlace;
        private System.Windows.Forms.Label lblGuess1;
        private System.Windows.Forms.Label lblGuess2;
        private System.Windows.Forms.Label lblGuess2ColorAndPlace;
        private System.Windows.Forms.Label lblGuess2Color;
        private System.Windows.Forms.Button btnGuess22;
        private System.Windows.Forms.Button btnGuess23;
        private System.Windows.Forms.Button btnGuess24;
        private System.Windows.Forms.Button btnGuess21;
        private System.Windows.Forms.Label lblGuess3;
        private System.Windows.Forms.Label lblGuess3ColorAndPlace;
        private System.Windows.Forms.Label lblGuess3Color;
        private System.Windows.Forms.Button btnGuess32;
        private System.Windows.Forms.Button btnGuess33;
        private System.Windows.Forms.Button btnGuess34;
        private System.Windows.Forms.Button btnGuess31;
        private System.Windows.Forms.Label lblGuess4;
        private System.Windows.Forms.Label lblGuess4ColorAndPlace;
        private System.Windows.Forms.Label lblGuess4Color;
        private System.Windows.Forms.Button btnGuess42;
        private System.Windows.Forms.Button btnGuess43;
        private System.Windows.Forms.Button btnGuess44;
        private System.Windows.Forms.Button btnGuess41;
        private System.Windows.Forms.Label lblGuess5;
        private System.Windows.Forms.Label lblGuess5ColorAndPlace;
        private System.Windows.Forms.Label lblGuess5Color;
        private System.Windows.Forms.Button btnGuess52;
        private System.Windows.Forms.Button btnGuess53;
        private System.Windows.Forms.Button btnGuess54;
        private System.Windows.Forms.Button btnGuess51;
        private System.Windows.Forms.Label lblGuess6;
        private System.Windows.Forms.Label lblGuess6ColorAndPlace;
        private System.Windows.Forms.Label lblGuess6Color;
        private System.Windows.Forms.Button btnGuess62;
        private System.Windows.Forms.Button btnGuess63;
        private System.Windows.Forms.Button btnGuess64;
        private System.Windows.Forms.Button btnGuess61;
        private System.Windows.Forms.Label lblGuess7;
        private System.Windows.Forms.Label lblGuess7ColorAndPlace;
        private System.Windows.Forms.Label lblGuess7Color;
        private System.Windows.Forms.Button btnGuess72;
        private System.Windows.Forms.Button btnGuess73;
        private System.Windows.Forms.Button btnGuess74;
        private System.Windows.Forms.Button btnGuess71;
        private System.Windows.Forms.Label lblGuess8;
        private System.Windows.Forms.Label lblGuess8ColorAndPlace;
        private System.Windows.Forms.Label lblGuess8Color;
        private System.Windows.Forms.Button btnGuess82;
        private System.Windows.Forms.Button btnGuess83;
        private System.Windows.Forms.Button btnGuess84;
        private System.Windows.Forms.Button btnGuess81;
        private System.Windows.Forms.Label lblGuess9;
        private System.Windows.Forms.Label lblGuess9ColorAndPlace;
        private System.Windows.Forms.Label lblGuess9Color;
        private System.Windows.Forms.Button btnGuess92;
        private System.Windows.Forms.Button btnGuess93;
        private System.Windows.Forms.Button btnGuess94;
        private System.Windows.Forms.Button btnGuess91;
        private System.Windows.Forms.Label lblGuess10;
        private System.Windows.Forms.Label lblGuess10ColorAndPlace;
        private System.Windows.Forms.Label lblGuess10Color;
        private System.Windows.Forms.Button btnGuess102;
        private System.Windows.Forms.Button btnGuess103;
        private System.Windows.Forms.Button btnGuess104;
        private System.Windows.Forms.Button btnGuess101;
        private System.Windows.Forms.Label lblMastermindTitle;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblEnterName;
        private System.Windows.Forms.TextBox txtEnterName;
        private System.Windows.Forms.Label lblSelectDifficulty;
        private System.Windows.Forms.Button btnEasy;
        private System.Windows.Forms.Button btnMedium;
        private System.Windows.Forms.Button btnHard;
        private System.Windows.Forms.Label lblScoreboard;
        private System.Windows.Forms.TextBox txtEasyWinner;
        private System.Windows.Forms.TextBox txtMediumWinner;
        private System.Windows.Forms.TextBox txtHardWinner;
        private System.Windows.Forms.Label lblEasyWinner;
        private System.Windows.Forms.Label lblMediumWinner;
        private System.Windows.Forms.Label lblHardWinner;
        private System.Windows.Forms.Label lblModeDisplayWinner;
        private System.Windows.Forms.Label lblNameDisplayWinner;
        private System.Windows.Forms.Button btnExit;
    }
}

